# React + Vite

Run `npm i` then `npm run dev`
